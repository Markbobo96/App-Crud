"""
Nombre: IA1
Mi primer pagina con Flask
23/11/2019
"""

#Importamos clase flask
from flask import Flask
from flask import render_template


#Creamos un objeto tipo app
app = Flask(__name__)

#Decoraciones
#Declarar las rutas de la app Web
@app.route('/') #ruta raíz localhost:5000
def index():
    return 'Hello World desde Flask'

#Declarar otra ruta y asociamos la funcion
@app.route("/mipagina") #ruta: localhost:5000/mipagina
def mipagina():
    return "<html><head><tittle>Mi primer paginilla</tittle></head><body><h1>Hola mundo peludo</h1></body></html>"

#Declaramos otra ruta y asociamos funciones
@app.route("/miweb") #ruta: localhost:5000/miweb
def miweb():
    name = "Mark Anthony Bonilla Bonilla"
    edad = 23
    materias = ["Inteligencia artificial","Programacion","Redes de computadoras","Doctrina"]
    return render_template("misdatos.html",nombre=name, age=edad, listmat=materias)


#Declararion de main
if __name__ == '__main__':
    app.run(debug=True, port=5000)
